import java.util.Scanner; // accept keyboard input
/**
 * Tester
 * Takes in user input and assigns it to the Balloon class. Then, calls methods from Balloon class.
 * 
 * @author Anthony Segarra 
 * @version 9/29/2022
 */

public class Main {
    
    public static void main(String[] args) {
        Scanner in = new Scanner (System.in);     // creates a new object for input(s)
         
        System.out.print("Enter color: ");        // request color
        String inputColor = in.nextLine();        // saves string input to a var
        
        System.out.print("Enter size: ");         // request size
        double inputSize = in.nextDouble();       // saves double input to a var
        
        Balloon newBalloon = new Balloon(inputColor, inputSize);     // creates new object for balloon var
        double inflatedSize = newBalloon.inflate(5);                 // adds 5 units to balloon size and saves value
        
        System.out.println("\nFor the " + newBalloon.getColor() + " balloon");      // prints balloon color
        System.out.println("Volume is now: " + newBalloon.volume(inflatedSize));    // prints balloon volume
    }
}
