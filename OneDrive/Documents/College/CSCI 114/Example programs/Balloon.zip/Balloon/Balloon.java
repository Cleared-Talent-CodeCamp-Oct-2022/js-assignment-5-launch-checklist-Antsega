import java.lang.Math; // for power function
/**
 * <DESC>
 * 
 * @Anthony Segarra
 * @29 Sept 2022
 */

public class Balloon {
    // constant variables below
    public static final double PI = 3.1415926;
    public static final double fractionConst = 4d/3d;   // 4d lets BlueJ know each number is a double so it can be divided
    
    // instance variables
    public String color = "";                           // place holder for future string
    public double size = 0.0;                           // place holder for future size
    public double volume = 0.0;                         // place holder for future volume
    // Constructor Start 
    public Balloon(String inputColor, double inputSize) {   // creates a Balloon with a color and size input
        this.color = inputColor;
        this.size = inputSize;
    }

    // Methods
    public double inflate(double input) {   // adds input to Balloon size
        size += input;
        return size;
    }
    
    public double volume(double size) {   // calculates volume of Balloon and returns a value, rounded to the nearest two digit
        volume = ((fractionConst) * (PI) * (Math.pow(size, 3)));
        return Math.round(volume * 100) / 100.0 ;
    }
    
    public String getColor() {          // returns Balloon color
        return color;
    }
}